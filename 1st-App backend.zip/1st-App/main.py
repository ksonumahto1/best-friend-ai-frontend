from flask import Flask, request, jsonify
from flask_cors import CORS
import random

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return "Flask server is running!"

@app.route('/api/test-cors')
def test_cors():
    return jsonify({"message": "CORS is enabled and working!"})

@app.route('/api/analyze-video', methods=['POST'])
def analyze_video():
    file = request.files.get('video')
    if not file:
        return jsonify({'error': 'No video file uploaded'}), 400

    # Simulate AI analysis with random results
    feedback = {
        "eye_contact": random.choice(["Good", "Average", "Needs Improvement"]),
        "smile": random.choice(["Natural", "Moderate", "Lacking"]),
        "voice": random.choice(["Clear", "Muffled", "Unclear"]),
        "posture": random.choice(["Confident", "Stiff", "Relaxed"]),
        "score": random.randint(60, 95)
    }
    return jsonify(feedback)
