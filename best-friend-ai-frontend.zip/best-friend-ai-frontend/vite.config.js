import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    allowedHosts: [
      '6bbfa3e0-5572-4e62-8594-92e2e0f6fa3c-00-1ysav1zt5d9fz.worf.replit.dev'
    ],
  },
});
