import React, { useState } from "react";
import axios from "axios";
import Webcam from "react-webcam";

interface Props {
  onFeedback: (data: any) => void; // Updated to pass full feedback
}

const VideoUpload: React.FC<Props> = ({ onFeedback }) => {
  const [uploadStatus, setUploadStatus] = useState("");
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [isRecording, setIsRecording] = useState(false);

  const webcamRef = React.useRef<Webcam>(null);
  const mediaRecorderRef = React.useRef<MediaRecorder | null>(null);
  const recordedChunks: Blob[] = [];

  const startRecording = () => {
    setIsRecording(true);
    recordedChunks.length = 0;
    const stream = webcamRef.current?.video?.srcObject as MediaStream;
    if (!stream) return;
    const mediaRecorder = new MediaRecorder(stream, { mimeType: "video/webm" });

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        recordedChunks.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(recordedChunks, { type: "video/webm" });
      setVideoBlob(blob);
    };

    mediaRecorderRef.current = mediaRecorder;
    mediaRecorder.start();
  };

  const stopRecording = () => {
    setIsRecording(false);
    mediaRecorderRef.current?.stop();
  };

  const uploadVideo = async () => {
    if (!videoBlob) return;
    setUploadStatus("Uploading...");
    const formData = new FormData();
    formData.append("video", videoBlob);

    try {
      const response = await axios.post(
        "https://350de233-f606-4fad-a566-11d55fb48af7-00-3m1de1i8alqz8.worf.replit.dev/api/analyze-video",
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );
      setUploadStatus("Analysis complete ✅");
      onFeedback(response.data); // Pass full feedback
    } catch (err) {
      setUploadStatus("Error uploading ❌");
      console.error(err);
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "1rem" }}>
      <Webcam audio={true} ref={webcamRef} width={300} />
      <div style={{ marginTop: "0.5rem" }}>
        {!isRecording ? (
          <button onClick={startRecording} style={{ backgroundColor: "green", color: "white" }}>
            🟢 Start Recording
          </button>
        ) : (
          <button onClick={stopRecording} style={{ backgroundColor: "red", color: "white" }}>
            🔴 Stop Recording
          </button>
        )}
      </div>

      {videoBlob && (
        <div style={{ marginTop: "1rem" }}>
          <button onClick={uploadVideo} style={{ backgroundColor: "#666", color: "#fff" }}>
            ⬆️ Upload & Analyze
          </button>
        </div>
      )}

      <p>{uploadStatus}</p>
    </div>
  );
};

export default VideoUpload;
