import React, { useState } from "react";
import "./App.css";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from "recharts";
import VideoUpload from "./VideoUpload";

const scenarios = [
  "Job Interview",
  "First Date",
  "Conflict Resolution",
  "Presentation Skills",
];

const App = () => {
  const [selectedScene, setSelectedScene] = useState("");
  const [score, setScore] = useState<number | null>(null);
  const [progress, setProgress] = useState<any[]>([]);
  const [feedback, setFeedback] = useState<any>(null);

  const startScene = (scene: string) => {
    setSelectedScene(scene);
    setScore(null);
    setFeedback(null);
  };

  const handleFeedback = (data: any) => {
    setFeedback(data);
    setScore(data.score);
    setProgress((prev) => [
      ...prev.filter((entry) => entry.name !== selectedScene),
      { name: selectedScene, score: data.score },
    ]);
  };

  const clearProgress = () => {
    setProgress([]);
    setSelectedScene("");
    setScore(null);
    setFeedback(null);
  };

  return (
    <div className="app-container">
      <h1 className="title">🎮 Best Friend AI</h1>

      {!selectedScene && (
        <>
          <p className="subtitle">Select a scenario to begin practicing communication skills:</p>
          <div className="scene-buttons">
            {scenarios.map((scene) => (
              <button key={scene} className="scene-btn" onClick={() => startScene(scene)}>
                {scene}
              </button>
            ))}
          </div>
        </>
      )}

      {selectedScene && (
        <div className="scene-container">
          <h2>Scenario: <strong>{selectedScene}</strong></h2>
          <VideoUpload onFeedback={handleFeedback} />
          {feedback && (
            <div className="feedback-card">
              <p>Analysis complete ✅</p>
              <h3>📊 AI Feedback:</h3>
              <ul>
                <li>Eye Contact: {feedback.eye_contact}</li>
                <li>Smile: {feedback.smile}</li>
                <li>Voice: {feedback.voice}</li>
                <li>Posture: {feedback.posture}</li>
                <li>Score: {feedback.score}/100</li>
              </ul>
              <button className="scene-btn" onClick={() => setSelectedScene("")}>
                🔁 Try Another Scene
              </button>
            </div>
          )}
        </div>
      )}

      {progress.length > 0 && (
        <div className="progress-chart">
          <h2>📈 Your Progress</h2>
          <BarChart width={360} height={200} data={progress}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="score" fill="#4a148c" /> {/* Purple color for visibility */}
          </BarChart>
          <button className="clear-btn" onClick={clearProgress}>🗑️ Clear Progress</button>
        </div>
      )}
    </div>
  );
};

export default App;
