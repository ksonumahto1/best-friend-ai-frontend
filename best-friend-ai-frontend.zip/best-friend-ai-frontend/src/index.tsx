// 🔇 Suppress Vite's WebSocket logs in Dev Console
const originalLog = console.log;
console.log = (...args) => {
  if (
    typeof args[0] === 'string' &&
    args[0].startsWith('[vite] ')
  ) {
    return;
  }
  originalLog(...args);
};


import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)